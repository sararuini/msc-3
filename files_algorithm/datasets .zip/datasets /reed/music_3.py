from reed import ReedClient
import os
import json               
import pandas as pd

music_keywords = ['music','falsetto', 'lyrics', 'music professional',
                'music distribution', 'music streaming',
                'digital downloads', 'music marketing', 'music promotion',
                'music events', 'music industry', 'music publishing',
                'live music industry', 'music community',
                'music charity', 'digital music', 'music licensing',
                 'album design', 'music education', 'music executive',
                 'music journalism', 'music store',
                 'musical instrument store', 'music shop', 'audio store',
                 'radio promotion',
                 'record shop', 'concert tour', 'artist tour']

music_instruments = ['guitar', 'bass guitar', 'bass', 'piano', 'electric keyboards', 'electric guitar', 'classical guitar', 'piano', 'singing', 'vocal',
                     'trumpet', 'ukulele', 'acccordion', 'cello', 'harmonica', 'harp', 'lute', 'mandolin', 'oboe', 'marimba', 'ocarina', 'recorder', 'saxophone', 'tuba', 'xylophone'
                     'clarinet', 'trombone', 'viola', 'violin', 'cornet' , 'cymbal', 'triangle', 'double bass', 'flute', 'french horn']

musician_jobs = ['guitarist', 'band member', 'bassist', 'pianist', 'vocalist', 'singer', 'orchestrator', 'composer', 'arranger', 'rapper', 'cellist',
                 'saxophonist','drummer', 'keyboardist','violinist', 'violist', 'conductor', 
                 'trumpeter', 'clarinettist', 'soprano', 'mezzo soprano', 'contralto', 'tenor', 'countertenor', 'baritone', 'orchestra', 'flutist']

music_teaching_jobs = ['music teacher', 'guitar teacher', 'guitar lesson', 'music lesson', 'bass guitar lesson', 'drums lesson', 'drums teacher', 'music lecturer',
                       'piano lesson', 'piano teacher', 'vocal coach']

music_production = ['music producer', 'music production', 'ableton', 'logic pro', 'pro tools', 'fl studio', 'garageband', 'cubase', 'audio engineer', 'audio engineering',
                    'audio interface', 'dj', 'disc jockey', 'arrangement', 'arranger', 'sound engineer', 'audio technician', '']

music_genres = ['rock', 'indie', 'jazz', 'pop music', 'rap', 'hip hop', 'contemporary music', 'classical music', 'kpop', 'jpop',
                'alternative music', 'opera', 'folk', 'metal', 'musical theatre', 'electronic music', 'dance music', 'house music',
                'reggae', 'punk', 'new wave', 'funk', 'dubstep', 'gospel', 'grunge', 'orchestra', 'ska', 'baroque music', 'drum and bass',
                'lo fi', 'blues', 'country music', 'ambient music', 'idm', 'ebm', 'disco music', 'techno', 'trap music', 'flamenco', 'latino music',
                'samba', 'mambo', 'reggaeton', 'synthpop', 'christian pop' ,'rhythm and blues', 'soul music', 'britpop', 'heavy metal', 'death metal',
                'doom metal', 'folk metal', 'glam metal', 'hardcore music'
               ]

music_industry_jobs = ['music sales', 'artist partnership manager',
'creative coordinator', 'music marketing manager', 'head of music',
'royalties assistant',
                      'recordings manager',]

music_publishing_legal = ['music licensing', 'music publisher', 'sync',
'synchronization rights', 'synch rights', 'mechanical rights',
'copyright collecting agency',
                          'performing rights','copyright', 'music lawyer',
                          'intellectual property', 'grand rights','mechanical license', 'performance royalties',
                          'performance rights organisation', 'royalties',  'music competition', 'music award', 'music market']

record_industry_artist_mgmt = ['record label', 'record company', 'a&r', 'artists and repertoire','sublabel', 'artist manager', 'band manager', 'recording artist',
                              'talent manager', 'label manager']

live_music_industry = ['concert tour', 'tour promoter', 'tour manager', 'road crew', 'roadie', 'concert promoter', 'music promoter', 'live music events organizer',
                       'music event','gig', 'event programmer']


all_music_keywords = music_instruments + musician_jobs + music_teaching_jobs + music_production + music_keywords + music_genres + music_industry_jobs + music_publishing_legal + record_industry_artist_mgmt + live_music_industry


api_key = "92faac8a-9fbe-4ec7-9017-c35816dbd0a2"

client = ReedClient(api_key=api_key)


def search_keywords(keyword, results, jsonFileName):
    resp = client.search(keywords=keyword, resultsToTake=results)

    with open(jsonFileName, 'w', encoding='utf-8') as f:
        json.dump(resp, f, ensure_ascii=False, indent=4)

search_keywords('music', 10000, 'music2.json')        
search_keywords('guitarist', 50, 'guitar.json')        
search_keywords('musician', 50, 'musician.json')
search_keywords('piano', 50, 'piano.json')
search_keywords('record industry', 50, 'record_industry.json')        
search_keywords('record company', 50, 'record_company.json')
search_keywords('record label', 50, 'record_label.json')        
search_keywords('music lesson', 100, 'music_lesson.json')        
search_keywords('music industry', 100, 'music_industry.json')        
search_keywords('music business', 100, 'music_business.json')
search_keywords('music marketing', 50, 'music_marketing.json')        
search_keywords('music publishing', 50, 'music_publishing.json')        
search_keywords('live music', 50, 'live_music.json')
search_keywords('concert', 50, 'concert.json')        
search_keywords('classical music', 50, 'classical_music.json')        
search_keywords('music shop', 50, 'music_shop.json')        
search_keywords('artist management', 50, 'artist_management.json')        
search_keywords('music venue', 50, 'music_venue.json')        
search_keywords('royalty', 50, 'royalty.json')        

#sources:
#https://github.com/theo-r/reed
# https://www.kite.com/python/answers/how-to-append-to-a-json-file-in-python
#https://stackoverflow.com/questions/12309269/how-do-i-write-json-data-to-a-file
#https://datascience.stackexchange.com/questions/62348/how-to-save-api-data-into-csv-format